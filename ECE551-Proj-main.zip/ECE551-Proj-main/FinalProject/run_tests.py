import os
import subprocess
import argparse
import time

# Paths
source_dir = "./"  # SystemVerilog source directory
test_dir = "./tests"  # testbench file directory
work_lib = "work"  # work library name

def compile_sources(verbose):
    if verbose:
        print("******************** STARTING COMPILATION **********************\n")
    
    # get all .sv files from the source and test directory
    sv_files = [os.path.join(source_dir, f) for f in os.listdir(source_dir) if f.endswith(".sv") or f.endswith(".vg") or f.endswith(".v")]
    sv_files += [os.path.join(test_dir, f) for f in os.listdir(test_dir) if f.endswith(".sv") or f.endswith(".vg") or f.endswith(".v")]
    
    if len(sv_files) == 0:
        print("No SystemVerilog source files found in the source directory.")
        return False
    
    # Compile all source files into the 'work' library
    compile_cmd = ["vlog", "-work", work_lib] + sv_files
    if verbose:
        print("Compiling source files: ", " ".join(sv_files))

    result = subprocess.run(compile_cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print("Error during source file compilation:\n", result.stdout)
        print("\n******************** COMPILATION COMPLETE **********************")
        return False
    
    if verbose:
        print("Source files compiled successfully.")
        print("\n******************** COMPILATION COMPLETE **********************")
    return True


def run_testbenches(verbose, long_run, single_tb=None):
    if verbose:
        print("******************** STARTING TESTBENCHES **********************")

    # Gather all testbench files from the tests directory
    if single_tb:
        tb_files = [os.path.join(test_dir, f'{single_tb}.sv')]
    else:
        tb_files = [os.path.join(test_dir, f) for f in os.listdir(test_dir) if f.endswith(".sv")]
        if not long_run and "./tests/KnightsTour_tb_entiretour.sv" in tb_files:
            if verbose:
                print("Not doing long run, so not performing KnightsTour_tb_entiretour");
            tb_files.remove("./tests/KnightsTour_tb_entiretour.sv");

    if len(tb_files) == 0:
        print("No testbench files found in the test directory.")
        return

    num_testbenches = 0
    num_successful_testbenches = 0

    successful_testbenches = []
    failed_testbenches = []

    for tb_file in tb_files:
        start_time = time.time()
        num_testbenches += 1

        tb_module = os.path.splitext(os.path.basename(tb_file))[0]  # module name
        if verbose:
            print(f"Running testbench: {tb_module}")
        
        # Run the testbench with vsim
        run_cmd = ['vsim', '-c',  '-voptargs="+acc"', f'work.{tb_module}', '-do', 'run -all; quit']
        result = subprocess.run(run_cmd, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"\tError during simulation ({tb_module}) with the following output:\n", result.stdout)
        else:
            if verbose:
                print(f"\tSimulation completed for testbench ({tb_module}) with the following output:\n\t\t", "\n\t\t".join(result.stdout.splitlines()[24:-7]))
        
        if verbose:
            end_time = time.time()
            minutes, seconds = divmod(end_time - start_time, 60)
            print(f"\tTestbend ({tb_module}) time spent: {int(minutes)}:{int(seconds):02d}")

        if "Test passed." in result.stdout.splitlines()[-8]: 
            num_successful_testbenches += 1
            successful_testbenches.append(tb_module)
            if verbose:
                print(f"\tTestbench ({tb_module}) passed.")
        else:
            failed_testbenches.append(tb_module)
            if verbose:
                print(f"\tTestbench ({tb_module}) failed.")
        

    
    print(f"Testbench results:\n\t{num_successful_testbenches}/{num_testbenches} passed")
    print(f"\tSuccessful testbenches: {successful_testbenches}")
    print(f"\tFailed testbenches: {failed_testbenches}")

    if verbose:
        print("******************** TESTBENCHES COMPLETE **********************")


if __name__ == "__main__":
    # Argument Parser
    parser = argparse.ArgumentParser(description="Run SystemVerilog testbench(es) with optional verbosity.")
    parser.add_argument(
        "-v", "--verbose", 
        action="store_true", 
        help="enable verbose output"
    )
    parser.add_argument(
        "-l", "--longrun", 
        action="store_true", 
        help="run full test suite, INCLUDING tb_entiretour which is extremely long"
    )
    parser.add_argument(
        "-s", "--single",
        type=str,
        metavar="<module name>",
        help="run a single testbench"
    )
    args = parser.parse_args()
    
    print("\n********************************************************************")
    print("******************* STARTING AUTOMATED TEST RUN ********************") 
    print("********************************************************************") 
    
    # Step 1: Compile all source files 
    if compile_sources(args.verbose): 
        # Step 2: Run all testbenches 
        run_testbenches(args.verbose, args.longrun, args.single)

    print("********************************************************************")
    print("******************* AUTOMATED TEST RUN COMPLETE ********************") 
    print("********************************************************************\n") 
    
